package com.amrita.jpl.cys21083.Practise.zBasicCalculations;

import java.util.Scanner;
public class SimpleCalculator {
    public static void main(String[] args) {
        int number1, number2, total;
        char operator;

        Scanner input = new Scanner(System.in); //Scanner Object

        System.out.println("Enter first number: ");
        number1 = input.nextInt();

        System.out.println("Enter second number: ");
        number2 = input.nextInt();

        System.out.println("Enter Operator for Calculation:  +, -, *, /: ");
        operator = input.next().charAt(0);

        switch (operator) {
            case '+':
                total = number1 + number2;
                System.out.println("Addition of " + number1 + " + " + number2 + " = " + total);
                break;

            case '-':
                total = number1 - number2;
                System.out.println("Subtraction of " + number1 + " - " + number2 + " = " + total);
                break;

            case '*':
                total = number1 * number2;
                System.out.println("Multiplication of " + number1 + " * " + number2 + " = " + total);
                break;

            case '/':
                total = number1 / number2;
                System.out.println("Division of " + number1 + " / " + number2 + " = " + total);
                break;

            default:
                System.out.println("Choose One of 4 Operators");
                break;
        }
    }
}


