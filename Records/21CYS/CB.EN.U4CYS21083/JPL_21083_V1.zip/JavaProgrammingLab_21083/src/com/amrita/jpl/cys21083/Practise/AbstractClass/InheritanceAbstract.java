package com.amrita.jpl.cys21083.Practise.AbstractClass;


// if a method is abstract then the inherited classes should have the definition of abstract method, or it throws an error
// A abstract method can be there only in abstract class

abstract class Shape {
    // abstract method without definition
    public abstract void area();

    // Method with definition
    public void display() {
        System.out.println("[Super] Calculating ");
    }
}

// Subclass (inherited from Shape)
class Circle extends Shape {
    public void area() {
        System.out.println("[Abstract Method in Circle] Area of Circle is PI*R*R");
    }
}

// Subclass (inherited from Shape)
class Rectangle extends Shape {
    public void area() {
        // area() of Rectangle Class - Definition
        System.out.println("[Abstract Method in Rectangle] Area of Rectangle is L*B");
    }
}

class Square extends Shape {
    public void area() {
        System.out.println("[Square] Area of the Circle is (side)^2 ");
    }
}

class Triangle extends Shape {
    public void area() {
        System.out.println("[Triangle] Area of Triangle is 1/2*base*height ");
    }
}

public class InheritanceAbstract {
    public static void main(String[] args){

        //   Shape myShape = new Shape(); //Try uncommenting this line.
        //error: Shape is abstract; cannot be instantiated
        // we cannot create an object for abstract class
        Circle myCircle = new Circle(); // Create a Circle object
        myCircle.display();
        myCircle.area();
        System.out.println("\n");
        Square sq = new Square(); //creating a square object
        sq.display();
        sq.area();
        System.out.println("\n");
        Rectangle myRect = new Rectangle(); // Create a Rectangle object
        myRect.display();
        myRect.area();
        System.out.println("\n");
        Triangle tri = new Triangle();
        tri.display();
        tri.area();
    }
}
