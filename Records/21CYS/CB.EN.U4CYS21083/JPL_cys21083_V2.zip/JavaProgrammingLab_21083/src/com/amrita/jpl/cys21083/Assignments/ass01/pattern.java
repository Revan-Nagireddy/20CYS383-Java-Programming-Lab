package com.amrita.jpl.cys21083.Assignments.ass01;

/**
 * @author Venkata Revan Nagireddy - CB.EN.U4CYS21083
 */
public class pattern {
    public static void main(String[] args) {
        for (int i = 0; i < 6; i++) {
            System.out.println("* * * * * * ==================================");
            System.out.println(" * * * * *  ==================================");
        }
        for (int i = 0; i < 6; i++) {
            System.out.println("==============================================");
        }
    }
}