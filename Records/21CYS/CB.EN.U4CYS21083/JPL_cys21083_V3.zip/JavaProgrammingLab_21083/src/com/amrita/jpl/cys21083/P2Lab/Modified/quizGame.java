package com.amrita.jpl.cys21083.P2Lab.Modified;

/**
 * @author Venkata Revan Nagireddy - CB.EN.U4CYS21082
 */

public abstract class quizGame {
    public abstract void startGame();
    public abstract void askQuestion();
    public abstract void evaluateAnswer(String answer);
}

